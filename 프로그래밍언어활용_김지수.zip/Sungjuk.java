package test;

import java.util.Scanner;

public class Sungjuk {

	public static void main(String[] args) {
	
	    Scanner scan= new Scanner(System.in);
	    
	    System.out.println("이름 입력 : ");
	    String name = scan.nextln();
	    System.out.println("점수 데이터 : ");
	    String jumsu = scan.nextln();
	    
	    int [] jumsu = new int[4];
	    for(int i=0; i<4; i++) {
	    	jumsu[i] = sc.nextInt();
	    }
	    System.out.println(Arrays.toString(jumsu));
	    
	    		
	    		
	    	
                }
	    	
	    }

	}
}
}
