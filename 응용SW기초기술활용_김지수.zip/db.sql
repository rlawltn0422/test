2) 관리자계정으로 들어가서 사용자 계정(user01 / 1234 )을  만드는 코드를 메모장으로 제출

C:\Users\jisu-> sqlplus
Enter user-name : [user01]
Enter password : [1234]

CREATE USER [user01] identified by [1234];



3) test라는 테이블을 만드는데, name(15), tel(10), email(50)의 크기를 가지는 작성 코드 메모장으로 제출

CREATE TABLE test
(
name(15),
tel(10),
email(50)
);

DESC test;



4) 다음 작업을 test테이블에 적용하는 코드를 만들어 메모장으로 제출
  데이터 입력 : (강호동, 123-1234, kang@ezen.co.kr), (유재석, 222-2323, you@ezen.co.kr)
  데이터 수정 : 강호동의 전화번호를 232-2323으로 변경
  데이터 삭제 : 유재석 삭제
  데이터 조회 : 강호동, 유재석 



INSERT INTO test VALUES (강호동, 123-1234, kang@ezen.co.kr);
INSERT INTO test VALUES (유재석, 222-2323, you@ezen.co.kr);
commit;

ALTER TABLE test RENAME COLUMN 123-1234 TO 232-2323;
commit;

ALTER TABLE test DROP COLUMN 유재석
commit;

SELECT * from all_col_comments where table_name='test';
commit;